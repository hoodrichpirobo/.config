local alpha = require("alpha")
local dashboard = require("alpha.themes.dashboard")

-- Replace header with your preferred ASCII art
local art = [[
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠴⠶⠶⠶⠶
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
]]

-- Split ASCII art into lines
local header = vim.split(art, "\n", { trimempty = true })

-- ====== Cool info block ======
local uv      = vim.uv or vim.loop
local uname   = (uv and uv.os_uname and uv.os_uname()) or { sysname = vim.loop.os_uname().sysname, release = "", machine = "" }
local user    = vim.env.USER or "user"
local host    = (vim.fn and vim.fn.hostname and vim.fn.hostname()) or "host"
local ver     = vim.version()
local term    = vim.env.TERM_PROGRAM or vim.env.TERM or "tty"
local shell   = (vim.env.SHELL and vim.fn.fnamemodify(vim.env.SHELL, ":t")) or (vim.o.shell and vim.fn.fnamemodify(vim.o.shell, ":t")) or "sh"
local cwd     = (uv and uv.cwd and uv.cwd()) or vim.fn.getcwd()
cwd           = vim.fn.fnamemodify(cwd, ":~")

local plugins = 0
do
  local ok, lazy = pcall(require, "lazy")
  if ok then
    local stats = lazy.stats()
    plugins = stats and stats.count or 0
  end
end

-- Append lines under the art
table.insert(header, "")
table.insert(header, "")
table.insert(header, "")
table.insert(header, "")
table.insert(header, "")
table.insert(header, "")
table.insert(header, ("      %s@%s          %s"):format(user, host, os.date("%H:%M")))
-- table.insert(header, ("   %s %s    %s"):format(uname.sysname or "OS", uname.release or "", uname.machine or ""))
-- table.insert(header, ("   Neovim %d.%d.%d    %s    %s"):format(ver.major, ver.minor, ver.patch, shell, term))
-- table.insert(header, ("   %s"):format(cwd))
-- table.insert(header, ("  %s"):format(os.date("%H:%M")))

dashboard.section.header.val = header
dashboard.section.header.opts = {
  position = "center",
  hl = "Function",  -- cámbialo si quieres otro color: "String", "Title", etc.
}

-- Botonera y footer (igual que antes)
dashboard.section.buttons.val = {
  dashboard.button("e", "  New file", ":ene <BAR> startinsert<CR>"),
  dashboard.button("f", "  Find file", ":Telescope find_files<CR>"),
  dashboard.button("r", "  Recent",    ":Telescope oldfiles<CR>"),
  dashboard.button("p", "  Projects",  ":Telescope projects<CR>"),
  dashboard.button("u", "  Update",    ":Lazy sync<CR>"),
  dashboard.button("q", "  Quit",      ":qa<CR>"),
}

dashboard.section.footer.val = { "Stay sharp. Stay pretty. " }
dashboard.section.footer.opts.hl = "Comment"

alpha.setup(dashboard.config)

