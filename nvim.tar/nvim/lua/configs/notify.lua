local notify = require("notify")
notify.setup({
  stages = "fade_in_slide_out",
  timeout = 2000,
  render = "compact",
  background_colour = "#000000",   -- honors transparency
})
vim.notify = notify

