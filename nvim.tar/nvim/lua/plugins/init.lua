-- All plugins are managed by lazy.nvim through NvChad’s layer
return {

  -- Pretty dashboard
  {
    "goolord/alpha-nvim",        -- dashboard framework :contentReference[oaicite:7]{index=7}
    event = "VimEnter",
    config = function()
      require("configs.alpha")
    end,
  },

  -- Better notifications + command-line UI
  {
    "rcarriga/nvim-notify",
    lazy = true,
    config = function()
      require("configs.notify")
    end,
  },
  {
    "folke/noice.nvim",
    event = "VeryLazy",
    dependencies = { "MunifTanjim/nui.nvim", "rcarriga/nvim-notify" },
    config = function()
      require("configs.noice")
    end,
  },

  -- Indent guides (minimal, no clutter)
  {
    "lukas-reineke/indent-blankline.nvim",
    main = "ibl",
    event = "BufReadPre",
    config = function()
      require("configs.ibl")
    end,
  },
}
