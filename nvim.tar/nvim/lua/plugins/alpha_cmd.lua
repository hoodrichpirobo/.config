-- Only load Alpha when the :Alpha command is used
return {
  {
    "goolord/alpha-nvim",
    event = nil,          -- remove VimEnter autostart
    cmd = { "Alpha" },    -- lazy-load on :Alpha
  },
}

