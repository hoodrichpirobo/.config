-- nvchad defaults
require "nvchad.options"

-- Always use the system clipboard for yanks/puts
vim.opt.clipboard = "unnamedplus"

-- Robust clipboard on WSL:
-- 1) If Wayland is available (WSLg GUI session) and wl-clipboard exists, use it (fast).
-- 2) Otherwise, use Windows clip.exe / powershell.exe (works in plain terminals).
if vim.fn.has("wsl") == 1 then
  local has_wl = (vim.fn.executable("wl-copy") == 1)
                 and (vim.fn.getenv("WAYLAND_DISPLAY") ~= vim.NIL)
                 and (tostring(vim.fn.getenv("WAYLAND_DISPLAY")) ~= "")

  if has_wl then
    -- Wayland/WSLg clipboard
    vim.g.clipboard = {
      name = "wl-clipboard (WSLg)",
      copy  = { ["+"] = "wl-copy",     ["*"] = "wl-copy"     },
      paste = { ["+"] = "wl-paste -n", ["*"] = "wl-paste -n" },
      cache_enabled = 0,
    }
  elseif vim.fn.executable("clip.exe") == 1 then
    -- Windows clipboard fallback (no Wayland session)
    local ps_paste = [[powershell.exe -NoProfile -NonInteractive -NoLogo -Command [Console]::Out.Write((Get-Clipboard -Raw) -replace "`r","")]]
    vim.g.clipboard = {
      name = "WSL Windows clipboard",
      copy  = { ["+"] = "clip.exe", ["*"] = "clip.exe" },
      paste = { ["+"] = ps_paste,   ["*"] = ps_paste   },
      cache_enabled = 0,
    }
  end
end

