---@type ChadrcConfig
local M = {}

-- NvChad UI & theme (built-in base46)
M.base46 = {
  theme = "catppuccin",          -- uses Catppuccin via base46 (mocha by default) :contentReference[oaicite:4]{index=4}
  theme_toggle = { "catppuccin", "one_light" },
  transparency = true,           -- glassy, pairs nicely with Windows Terminal opacity :contentReference[oaicite:5]{index=5}

  telescope = { style = "borderless" }, -- looks clean with your setup

  statusline = {                 -- NvChad’s own statusline styles :contentReference[oaicite:6]{index=6}
    theme = "vscode_colored",    -- colorful but tasteful
  },

  nvdash = {                     -- enable dashboard shell (we’ll override with alpha)
    load_on_startup = false
  },
}

-- Tell NvChad where our plugin spec lives
M.plugins = "plugins"

return M
